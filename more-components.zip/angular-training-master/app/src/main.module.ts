import {NgModule} from "@angular/core";
import {BrowserModule} from "@angular/platform-browser";
import {platformBrowserDynamic} from "@angular/platform-browser-dynamic";
import {FormsModule} from "@angular/forms";

import {CoolComponent} from "./cool.component";
import {PersonComponent} from "./person.component";
import {OrderComponent} from "./order.component";
import {CityComponent} from "./city.component";
import {ShapeComponent} from "./shape.component";
import {UserComponent} from "./user.component";
import {CalComponent} from "./cal.component";


@NgModule({
	imports:[BrowserModule,FormsModule],
	declarations:[CalComponent,UserComponent,ShapeComponent,CityComponent,OrderComponent,CoolComponent,PersonComponent],
	bootstrap:[PersonComponent]
})
class MainModule {
	
	constructor(){
		console.log("Inside MainModule constructor!!!!");
	}	
}

platformBrowserDynamic().bootstrapModule(MainModule);




