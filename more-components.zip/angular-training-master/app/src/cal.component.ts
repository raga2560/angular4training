import {Component} from "@angular/core";

@Component({
	template:`<div>
		<h1>{{title}}</h1>
		<form>
			Enter Number : <input type=text [(ngModel)]='valOne' name='one' /><br/>
			Enter Number : <input type=text [(ngModel)]='valTwo' name='two' /><br/>
			               <input type=button value='SUM' (click)='doSum()' /><br/>
		</form>
		<hr/>
		<h1>Result : {{result}}</h1>
	</div>`,
	selector:'cool-app'
})
export class CalComponent {

	title:string = 'Simple Calculator';
	valOne:number = 10;
	valTwo:number = 10;
	result:number = 0;

	doSum(){
		this.result = parseInt(this.valOne) + parseInt(this.valTwo); 
	}	
	
}
