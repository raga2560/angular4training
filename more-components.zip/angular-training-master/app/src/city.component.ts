import {Component} from "@angular/core";

@Component({
	template:`<div>
		<h1>I am living in {{cityName}}</h1>
		<form>
			Enter City : <input type=text [(ngModel)]='cityName' name='city' />
		</form>
		<h1>I am living in {{cityName}}</h1>
		<h1>I am living in {{cityName}}</h1>
		<h1>I am living in {{cityName}}</h1>
		<h1>I am living in {{cityName}}</h1>
		<h1>I am living in {{cityName}}</h1>
	</div>`,
	selector:'cool-app'
})
export class CityComponent {

	cityName:string = "Pune";
}
