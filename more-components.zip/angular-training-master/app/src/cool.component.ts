import {Component} from "@angular/core";

@Component({
	template:`<h1 class='beautify'>Cool Looking Component</h1>`,
	selector:'cool-app',
	styles:[`

		.beautify {
			color:white;
			background-color:blue;
			width:55%;
			text-align:center;
			margin:auto;
			margin-top:50px;
			border:10px inset red;
			border-radius:20px;
			box-shadow:20px 40px 50px yellow;
		}		

	`]
})
export class CoolComponent {

	constructor(){
		console.log("Inside CoolComponent constructor!!!!");
	}	
	
}