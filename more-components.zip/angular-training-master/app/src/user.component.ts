import {Component,OnInit,OnDestroy} from "@angular/core";

@Component({
	template:`<div>
		<form>
			Enter Age : <input type=text [(ngModel)]='age' name='u_age' />
			<input type=button value='Show Age' (click)='display();' />
		</form>
	</div>`,
	selector:'cool-app'
})
export class UserComponent implements OnInit,OnDestroy {

	age = 20;

	constructor(){
		console.log("Inside UserComponent constructor()!!!!!");
	}

	display(){
		console.log("Age is "+this.age);
	}

	ngOnInit(){
		console.log("Inside UserComponent ngOnInit()!!!!!");
	}

	ngOnDestroy(){
		console.log("Inside UserComponent ngOnDestro()!!!!!");
	}

}
