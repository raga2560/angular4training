import {Component} from "@angular/core";

@Component({
	template:`<div>
		<h1>Color is {{color}}</h1>
		<input (click)='changeColor();' type=button value='Change' />
	</div>`,
	selector:'cool-app'
})
export class ShapeComponent {

	color:string = "Green";

	changeColor(){
		console.log("Color changed!!!!");
		this.color = "Red";
	}
}
