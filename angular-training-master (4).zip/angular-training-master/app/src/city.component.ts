import {Component} from "@angular/core";

@Component({
	template:`<div>
		<h1>I am living in {{cityName}}</h1>
		<form>
			Enter City : <input type=text [(ngModel)]='cityName' name='city' />
		</form>
	</div>`,
	selector:'city-info'
})
export class CityComponent {

	cityName:string = "Pune";
}
