import {Component} from "@angular/core";

@Component({
	template:`<div>
		<h1>{{title}}</h1>
		<p>Enjoy the meal full day/ Lots of choices.</p>
		<hr/>
		<input (click)='placeOrder(1050);' type=button value='Place Order' />
	</div>`,
	selector:'cool-app'
})
export class OrderComponent {

	title:string = "Enjoy the meal";

	constructor(){
		console.log("Inside OrderComponent constructor!!!!");
	}

	placeOrder(oid:number){
		console.log("Order ID "+oid+" has been placed !!!!!");
	}	
	
}