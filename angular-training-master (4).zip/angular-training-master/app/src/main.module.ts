import {NgModule} from "@angular/core";
import {BrowserModule} from "@angular/platform-browser";
import {platformBrowserDynamic} from "@angular/platform-browser-dynamic";
import {FormsModule} from "@angular/forms";

import {CalComponent} from "./cal.component";
import {CityComponent} from "./city.component";
import {PersonComponent} from "./person.component";
import {AppComponent} from "./app.component";
import {UserComponent} from "./user.component";


@NgModule({
	imports:[BrowserModule,FormsModule],
	declarations:[UserComponent,AppComponent,CalComponent,CityComponent,PersonComponent],
	bootstrap:[UserComponent]
})
class MainModule {
}

platformBrowserDynamic().bootstrapModule(MainModule);




