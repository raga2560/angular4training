//angular imports
import {Component,Inject} from "@angular/core";

//application imports
import {ICalService} from "./cal.interface";
import {JokeService} from "./joke.service";

@Component({
	template:`<div>
		<p>{{joke}}</p>
		<h1>{{title}}</h1>
		<form>
			Enter Number : <input type=number [(ngModel)]='valOne' name='one' /><br/>
			Enter Number : <input type=number [(ngModel)]='valTwo' name='two' /><br/>
			               <input type=button value='SUM' (click)='doSum()' />
			               <input type=button value='DIFF' (click)='doDiff()' /><br/>
		</form>
		<hr/>
		<h1>Result : {{result}}</h1>
	</div>`,
	selector:'app'
})
export class CalComponent {

	title:string = 'Simple Calculator';
	valOne:number = 10;
	valTwo:number = 10;
	result:number = 0;
	joke:string;

	/*constructor(@Inject('ICalService') private calService:ICalService){
	}*/

	constructor(private jokeService:JokeService,@Inject('IMathService') private calService:ICalService){
		this.joke = this.jokeService.nextJoke();
	}
	

	doSum(){
		this.result = this.calService.sum(this.valOne,this.valTwo);
	}	
	
	doDiff(){
		this.result = this.calService.diff(this.valOne,this.valTwo);
	}	

}
