import {ICalService} from "./cal.interface";

export class CalService implements ICalService{
	
	sum(valOne:number,valTwo:number):number{
		console.log("Inside CalService sum()");
		return valOne+valTwo;
	}

	diff(valOne:number,valTwo:number):number{
		console.log("Inside CalService diff()");
		return valOne-valTwo;
	}

	multiply(valOne:number,valTwo:number):number{
		console.log("Inside CalService multiply()");
		return valOne*valTwo;
	}

	divide(valOne:number,valTwo:number):number{
		console.log("Inside CalService divide()");
		return valOne/valTwo;
	}

}