export class JokeService{
	
	nextJoke():string{
		let jokes = [
			'Training will finish at 9 P.M.',
			'Fridays are very boring.',
			'Mondays are amazing.',
			'Tusedays are always welcome.'
		];

		let idx = Math.floor(Math.random()*jokes.length);
		return jokes[idx];
	}
		
}