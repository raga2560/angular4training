import {Component} from "@angular/core";

@Component({
	template:`<div>
		<h1 *ngIf='state'>Hello</h1>
		<h1 *ngIf='age'>You are old.</h1>
		<h1 *ngIf='city'>I live here.</h1>
		<h1 *ngIf='age > 20'>You are old.</h1>
		<h1 *ngIf='age <= 20'>You are young.</h1>
		<h1 [hidden]='true'>Color is blind.</h1>
		<ul>
			<li *ngFor='let color of colors'>
				<p>{{color}}</p>
			</li>
		</ul>
	</div>`,
	selector:'app'
})
export class UserComponent {
	
	city:string = "Delhi";
	age:number = 20;	
	state:boolean = true;	
	colors:string[];

	constructor(){
		this.colors = ['Red','Green','Blue','Yellow'];
	}	
}






