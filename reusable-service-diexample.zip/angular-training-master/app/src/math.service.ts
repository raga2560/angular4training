export class MathService {
	
	sum(valOne:number,valTwo:number):number{
		console.log("Inside MathService sum()");
		return valOne+valTwo;
	}

	diff(valOne:number,valTwo:number):number{
		console.log("Inside MathService diff()");
		return valOne-valTwo;
	}

	multiply(valOne:number,valTwo:number):number{
		console.log("Inside MathService multiply()");
		return valOne*valTwo;
	}

	divide(valOne:number,valTwo:number):number{
		console.log("Inside MathService divide()");
		return valOne/valTwo;
	}

}