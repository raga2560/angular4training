import {Component} from "@angular/core";

import {JokeService} from "./joke.service";

@Component({
	providers:[JokeService],
	template:`<div>
		<h1>I am living in {{cityName}}</h1>
		<form>
			Enter City : <input type=text [(ngModel)]='cityName' name='city' />
		</form>
	</div>`,
	selector:'city-app'
})
export class CityComponent {

	cityName:string = "Pune";
	
	constructor(private jokeService:JokeService){
	}

}
