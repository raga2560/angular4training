import {Component} from "@angular/core";

@Component({
	template:`<div class='container'>
		<h1>{{title}}</h1>
		<calculator></calculator>
		<city-info></city-info>
		<p style='clear:both'></p>
		<hr/>
		<person-detail></person-detail>
	</div>`,
	selector:'app',
	styles:[`

		.container{
			width:90%;
		}

		.container h1{
			background-color:blue;
			color:white;
			width:80%;
			margin:auto;
			margin-top:10px;
			text-align:center;	
		}
		
		.container calculator{
			width:40%;
			float:left;
			margin-left:20px;
			text-align:center;	
		}
	
		.container city-info{
			width:50%;
			float:right;
			margin-right:20px;
			text-align:center;	
		}

	`]
})
export class AppComponent {

	title:string = "IBM Corp.";
}
