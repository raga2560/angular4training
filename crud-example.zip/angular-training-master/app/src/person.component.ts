import {Component} from "@angular/core";
import {Person} from "./person";

@Component({
	templateUrl:'partials/person.component.html',
	selector:'person-detail',
	styleUrls:['css/person.component.css']
})
export class PersonComponent {

	title = "Person Detail Component";
	person:Person;
	size = {w:200,h:100};

	constructor(){
		console.log("Inside PersonComponent constructor!!!!");
		this.person = new Person(1000,'Rohan',34,new Date(),'images/person1.jpg');
	}	

	changeLogo(){
		this.person.logo = "images/person3.jpg";
	}	
}