export class Person {

	uid:number;
	name:string;
	age:number;
	dob:date;
	logo:string;

	
	constructor(uid:number,name:string,age:number,dob:date,logo:string){
		this.uid = uid;
		this.name = name;
		this.age = age;
		this.dob = dob;
		this.logo = logo;
	}
	
}