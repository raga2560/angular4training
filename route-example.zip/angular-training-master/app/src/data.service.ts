export class DataService{
	
	const jokes:string[] = [
			'Training will finish at 9 P.M.',
			'Fridays are very boring.',
			'Mondays are amazing.',
			'Tusedays are always welcome.'
	];

	readAll():string[]{
		return this.jokes;
	}
		
}