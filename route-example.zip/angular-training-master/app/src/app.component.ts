import { Component } from '@angular/core';

@Component({
  selector: 'app',
  template: `<h1> {{title}} </h1>
  			<nav>
  				<ul>
  					<li><a routerLink='/news'>News</a></li>
  					<li><a routerLink='/weather'>Weather</a></li>
  					<li><a routerLink='/cricket'>Cricket</a></li>
  					<li><a routerLink='/cal'>Calculator</a></li>
  					<li><a routerLink='/carlist'>CarList</a></li>
  					<li><a routerLink=''>Products</a></li>
  					<li><a routerLink=''>Partners</a></li>
  				</ul>
  			</nav>
  			<router-outlet></router-outlet>
	   `,
	styles:[`
		
		nav{
			background-color:black;
		}		

		li {
			display:inline;
		}
		
		li a{
			color:white;
			font-size:20px;
			text-decoration:none;
		}
	`]
})
export class AppComponent {
  title:string = 'IBM Corp';
}
