import {NgModule} from "@angular/core";
import {BrowserModule} from "@angular/platform-browser";
import {platformBrowserDynamic} from "@angular/platform-browser-dynamic";
import {FormsModule} from "@angular/forms";

import {CalComponent} from "./cal.component";
import {CityComponent} from "./city.component";
import {PersonComponent} from "./person.component";
import {AppComponent} from "./app.component";
import {UserComponent} from "./user.component";

import {ICalService} from "./cal.interface";
import {CalService} from "./cal.service";
import {MathService} from "./math.service";
import {JokeService} from "./joke.service";
import {DataService} from "./data.service";


@NgModule({
	imports:[BrowserModule,FormsModule],
	//providers:[CalService],
	providers:[
		DataService,
		//JokeService,
		{provide:'ICalService',useClass: CalService},
		{provide:'IMathService',useClass: MathService}
	],
	declarations:[UserComponent,CalComponent,CityComponent,PersonComponent],
	bootstrap:[CalComponent,CityComponent]
})
class MainModule {
}

platformBrowserDynamic().bootstrapModule(MainModule);




