import {NgModule} from "@angular/core";
import {BrowserModule} from "@angular/platform-browser";
import {FormsModule} from "@angular/forms";

import {CarListComponent} from "./carlist.component";
import {CarComponent} from "./car.component";
import {HomeComponent} from "./home.component";
import {CricketComponent} from "./cricket.component";
import {NewsComponent} from "./news.component";
import {WeatherComponent} from "./weather.component";
import {AppComponent} from "./app.component";

import {CarService} from "./car.service";

import {initializedRoutes} from "./app.routes";

@NgModule({
	imports:[BrowserModule,FormsModule,initializedRoutes],
	providers:[CarService],
	declarations:[AppComponent,HomeComponent,CricketComponent,NewsComponent,WeatherComponent,CarListComponent,CarComponent],
	bootstrap:[AppComponent]
})
export class AppModule {
}





