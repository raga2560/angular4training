import {Routes,RouterModule} from "@angular/router";

import {CarListComponent} from "./carlist.component";
import {HomeComponent} from "./home.component";
import {CricketComponent} from "./cricket.component";
import {NewsComponent} from "./news.component";
import {WeatherComponent} from "./weather.component";

const appRoutes:Routes = [
	{
		path:'home',
		component:HomeComponent	
	},
	{
		path:'news',
		component:NewsComponent	
	},
	{
		path:'weather',
		component:WeatherComponent	
	},
	{
		path:'cricket',
		component:CricketComponent	
	},
	{
		path:'carlist',
		component:CarListComponent	
	},
	{
		path:'',
		redirectTo:'/home',
		pathMatch: 'full'
	}
];


export const initializedRoutes = RouterModule.forRoot(appRoutes);
