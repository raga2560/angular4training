import {Component,Input,OnInit,EventEmitter,Output} from "@angular/core";

import {Car} from "./car";
import {CarService} from "./car.service";

@Component({
	templateUrl:'partials/car.component.html',
	styleUrls:['css/car.component.css'],
	selector:'car-form'
})
export class CarComponent implements OnInit {

	title:string = 'Car Entry Form';

	@Input()
	editMode:boolean;

	@Input()
	car:Car;


	@Output()
	carUpdated = new EventEmitter();

	@Output()
	carAdded = new EventEmitter();

	constructor(private carService:CarService){
	}

	ngOnInit(){
		this.car = new Car();
		this.editMode = false;
	}

	doAdd(){
		this.carAdded.emit({
			car:this.car
		});	
	}

	doUpdate(){
		this.carUpdated.emit({
			author:'Ritesh',
			timestamp:'8-Sep-2017',
			car:this.car
		});	
		console.log('carUpdated event is just fired!!!!');
	}
}
