import {Component} from "@angular/core";

import {Car} from "./car";
import {CarService} from "./car.service";

@Component({
	templateUrl:'partials/carlist.component.html',
	styleUrls:['css/carlist.component.css'],
	selector:'app'
})
export class CarListComponent implements OnInit{

	title:string = 'Dream Car List';
	cars:Car[];
	imagePath:string = "images/";
	selectedCar:Car;
	edit:boolean;

	constructor(private carService:CarService){
	}

	ngOnInit(){
		this.cars = this.carService.readAll();
	}

	doDelete(vin:number){
		this.carService.deleteCar(vin);
		console.log(`Car with ${vin} deleted!!!!`);
	}	

	doEdit(car:Car){
		this.selectedCar = JSON.parse(JSON.stringify(car));
		this.edit = true;
		console.log(`Car with ${car.vin} is opened in edit mode!!!!`);
	}	

	doUpdate(evt){
		this.carService.updateCar(evt.car);
		console.log(evt.timestamp);
		console.log(evt.author);
		console.log('Indise CarListComponent doUpdate()!!!!!');
	}

	doAdd(evt){
		this.carService.addCar(JSON.parse(JSON.stringify(evt.car)));
		console.log('Indise CarListComponent doAdd()!!!!!');
	}

}
