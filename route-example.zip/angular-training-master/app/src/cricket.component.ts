import {Component} from "@angular/core";

@Component({
	selector:'cricket',
	template:`
		<h1>{{title}}</h1>
		<div>{{summary}}</div>
	`
})
export class CricketComponent{
	title:string = "Cricket Match";
	summary:string = "20:20 final is on tomorrow!!";
}



