import {Car} from "./car";

export class CarService {

	cars:Car[] = [
				new Car(1000,'X1','BMW',2400000,'Black','x1.png'),
				new Car(1001,'X3','BMW',5400000,'Black','x3.png'),
				new Car(1002,'A1','Audi',6700000,'Red','a1.png'),
				new Car(1003,'Q5','Audi',9900000,'Black','q5.png'),
				new Car(1004,'XE','Jaquar',78900000,'Yellow','xe.png'),
				new Car(1005,'CD1','Mers',189000,'Black','xe.png'),
				new Car(1006,'A5','Audi',900000,'White','a5.png')
	];

	readAll(){
		return this.cars;
	}

	addCar(car:Car){
		var vin = this.cars.length + 1000; 
		car.vin = vin;
		this.cars.push(car);
	}


	updateCar(car:Car){
		console.log(car.vin);

		for(var idx=0;idx<this.cars.length;idx++){
			//console.log("Inside loop");
			var existingCar = this.cars[idx];
			if(existingCar.vin === car.vin){
				//console.log("Inside condition");
				this.cars[idx] = car;
				//console.log(this.cars[idx]);
				break;
			}	
		}
	}
	
	deleteCar(vin:number){
		for(var idx=0;idx<this.cars.length;idx++){
			var car = this.cars[idx];
			if(car.vin === vin){
				this.cars.splice(idx,1);
				break;
			}	
		}
	}
	
}