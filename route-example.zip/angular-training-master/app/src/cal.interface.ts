export interface ICalService{
	sum(valOne:number,valTwo:number);
	diff(valOne:number,valTwo:number);
	multiply(valOne:number,valTwo:number);
	divide(valOne:number,valTwo:number);
}

